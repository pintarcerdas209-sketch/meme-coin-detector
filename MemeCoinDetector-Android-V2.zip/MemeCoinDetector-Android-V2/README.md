# Meme Coin Detector Android V2

V2 menambahkan:
- Market score
- Risk score
- Liquidity dan volume
- Buy/sell activity
- Pemeriksaan Solana mint authority
- Pemeriksaan Solana freeze authority
- Top-5 token-account concentration
- Warning heuristik
- Scan alamat token tertentu
- Scan token Solana terbaru

## Build APK
Buka folder ini di Android Studio, lakukan Gradle Sync, lalu:
Build > Build APK(s)

APK debug:
app/build/outputs/apk/debug/app-debug.apk

## Catatan keamanan
Top-5 concentration menggunakan 20 token accounts terbesar dari RPC dan dapat memasukkan LP/pool account. Jadi angka tersebut adalah indikator screening, bukan bukti rug pull.

Mint/freeze authority aktif meningkatkan risk score, tetapi tidak otomatis berarti scam.

V2 belum melakukan audit penuh terhadap source code, transaksi developer, liquidity lock, atau simulasi sell/honeypot. Jangan gunakan score sebagai jaminan keuntungan.
