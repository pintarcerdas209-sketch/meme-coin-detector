package com.example.memecoindetector

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.min

data class Security(
    val supply: Double,
    val top5Pct: Double,
    val mintAuthority: String?,
    val freezeAuthority: String?
)

data class Analysis(
    val symbol: String,
    val name: String,
    val address: String,
    val liquidity: Double,
    val volume1h: Double,
    val buys: Int,
    val sells: Int,
    val marketScore: Int,
    val riskScore: Int,
    val security: Security?,
    val warnings: List<String>
)

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var scanButton: Button
    private lateinit var status: TextView
    private lateinit var resultBox: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    private val dexProfiles = "https://api.dexscreener.com/token-profiles/latest/v1"
    private val solanaRpc = "https://api.mainnet.solana.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.rgb(16,16,16))
        }

        val title = tv("🪙 Meme Coin Detector V2", 25f, Color.WHITE)
        val subtitle = tv(
            "Solana • market + holder concentration + mint/freeze risk",
            13f, Color.LTGRAY
        )

        input = EditText(this).apply {
            hint = "Tempel alamat token Solana (opsional)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(16, 8, 16, 8)
        }

        scanButton = Button(this).apply {
            text = "SCAN TOKEN"
            setOnClickListener { startScan() }
        }

        val autoButton = Button(this).apply {
            text = "SCAN TOKEN BARU"
            setOnClickListener { scanNewTokens() }
        }

        status = tv("Pilih scan token atau scan token baru.", 13f, Color.LTGRAY)
        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val scroll = ScrollView(this).apply { addView(resultBox) }

        root.addView(title)
        root.addView(subtitle)
        root.addView(input)
        root.addView(scanButton)
        root.addView(autoButton)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startScan() {
        val address = input.text.toString().trim()
        if (address.isBlank()) {
            status.text = "Masukkan mint address terlebih dahulu."
            return
        }
        scanAddress(address)
    }

    private fun scanNewTokens() {
        setBusy("Mengambil token terbaru...")
        executor.execute {
            try {
                val arr = JSONObject.wrap(JSONArrayHelper.parse(get(dexProfiles)))
                // JSONObject.wrap above is only a convenient holder; actual list is parsed below.
                val profiles = org.json.JSONArray(get(dexProfiles))
                val addresses = mutableListOf<String>()
                for (i in 0 until min(profiles.length(), 8)) {
                    val p = profiles.optJSONObject(i) ?: continue
                    if (p.optString("chainId") == "solana") {
                        val a = p.optString("tokenAddress")
                        if (a.isNotBlank()) addresses.add(a)
                    }
                }
                runOnUiThread {
                    resultBox.removeAllViews()
                    status.text = "Menganalisis ${addresses.size} token..."
                }
                for (address in addresses) {
                    try {
                        val a = analyze(address)
                        runOnUiThread { addCard(a) }
                    } catch (_: Exception) {}
                }
                runOnUiThread {
                    status.text = "Selesai. Hasil V2 ditampilkan di bawah."
                    scanButton.isEnabled = true
                }
            } catch (e: Exception) {
                showError(e)
            }
        }
    }

    private fun scanAddress(address: String) {
        setBusy("Menganalisis token...")
        executor.execute {
            try {
                val result = analyze(address)
                runOnUiThread {
                    resultBox.removeAllViews()
                    addCard(result)
                    status.text = "Analisis selesai."
                    scanButton.isEnabled = true
                }
            } catch (e: Exception) {
                showError(e)
            }
        }
    }

    private fun analyze(address: String): Analysis {
        val market = JSONObject(get(
            "https://api.dexscreener.com/latest/dex/tokens/$address"
        ))
        val pairs = market.optJSONArray("pairs")
            ?: throw RuntimeException("Market pair tidak ditemukan.")

        var pair: JSONObject? = null
        for (i in 0 until pairs.length()) {
            val p = pairs.optJSONObject(i) ?: continue
            if (p.optString("chainId") == "solana") {
                pair = p
                break
            }
        }
        val p = pair ?: throw RuntimeException("Pair Solana tidak ditemukan.")

        val base = p.optJSONObject("baseToken") ?: JSONObject()
        val symbol = base.optString("symbol", "?")
        val name = base.optString("name", "Unknown")
        val liquidity = p.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
        val volume = p.optJSONObject("volume")?.optDouble("h1", 0.0) ?: 0.0
        val tx = p.optJSONObject("txns")?.optJSONObject("h1")
        val buys = tx?.optInt("buys", 0) ?: 0
        val sells = tx?.optInt("sells", 0) ?: 0

        val security = getSecurity(address)
        val warnings = mutableListOf<String>()

        if (security != null) {
            if (security.mintAuthority != null) warnings.add("Mint authority masih aktif")
            if (security.freezeAuthority != null) warnings.add("Freeze authority masih aktif")
            if (security.top5Pct >= 50) warnings.add("Top 5 holder sangat terkonsentrasi")
            else if (security.top5Pct >= 25) warnings.add("Top 5 holder cukup terkonsentrasi")
        } else {
            warnings.add("Data security/holder tidak tersedia")
        }
        if (liquidity < 5000) warnings.add("Liquidity sangat rendah")
        if (liquidity in 5000.0..25000.0) warnings.add("Liquidity rendah")
        if (buys + sells < 25) warnings.add("Aktivitas transaksi rendah")

        var marketScore = 0
        if (liquidity >= 100000) marketScore += 25
        else if (liquidity >= 25000) marketScore += 18
        else if (liquidity >= 5000) marketScore += 10
        if (volume >= 100000) marketScore += 20
        else if (volume >= 25000) marketScore += 14
        else if (volume >= 5000) marketScore += 8
        val total = buys + sells
        if (total >= 500) marketScore += 20
        else if (total >= 100) marketScore += 14
        else if (total >= 25) marketScore += 8
        if (total > 0) {
            val balance = min(buys, sells).toDouble() / maxOf(buys, sells)
            if (balance >= .5) marketScore += 15
            else if (balance >= .25) marketScore += 8
        }
        if (security?.top5Pct != null && security.top5Pct < 25) marketScore += 20
        marketScore = marketScore.coerceAtMost(100)

        var risk = 0
        if (security == null) risk += 15
        if (security?.mintAuthority != null) risk += 25
        if (security?.freezeAuthority != null) risk += 20
        if (security?.top5Pct != null) {
            if (security.top5Pct >= 50) risk += 30
            else if (security.top5Pct >= 25) risk += 15
        }
        if (liquidity < 5000) risk += 20
        else if (liquidity < 25000) risk += 10
        if (total < 25) risk += 10
        risk = risk.coerceAtMost(100)

        return Analysis(
            symbol, name, address, liquidity, volume, buys, sells,
            marketScore, risk, security, warnings
        )
    }

    private fun getSecurity(mint: String): Security? {
        return try {
            val body = """{"jsonrpc":"2.0","id":1,"method":"getAccountInfo","params":["$mint",{"encoding":"jsonParsed","commitment":"finalized"}]}"""
            val account = JSONObject(post(solanaRpc, body))
                .optJSONObject("result")?.optJSONObject("value") ?: return null
            val data = account.optJSONObject("data") ?: return null
            val parsed = data.optJSONObject("parsed") ?: return null
            val info = parsed.optJSONObject("info") ?: return null
            val supplyRaw = info.optString("supply", "0").toDoubleOrNull() ?: 0.0
            val decimals = info.optInt("decimals", 0)
            val supply = supplyRaw / Math.pow(10.0, decimals.toDouble())
            val mintAuthority = info.optString("mintAuthority").ifBlank { null }
            val freezeAuthority = info.optString("freezeAuthority").ifBlank { null }

            val largestBody = """{"jsonrpc":"2.0","id":2,"method":"getTokenLargestAccounts","params":["$mint",{"commitment":"finalized"}]}"""
            val largest = JSONObject(post(solanaRpc, largestBody))
                .optJSONObject("result")?.optJSONArray("value")
            var top5 = 0.0
            if (largest != null) {
                for (i in 0 until min(5, largest.length())) {
                    val amount = largest.optJSONObject(i)?.optString("uiAmountString")
                        ?.toDoubleOrNull() ?: 0.0
                    top5 += amount
                }
            }
            val topPct = if (supply > 0) (top5 / supply) * 100.0 else 0.0
            Security(supply, topPct, mintAuthority, freezeAuthority)
        } catch (_: Exception) {
            null
        }
    }

    private fun addCard(a: Analysis) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(30,30,30))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 0, 0, 14)
            layoutParams = lp
        }

        card.addView(tv("${a.symbol} • ${a.name}", 20f, Color.WHITE))
        card.addView(tv(
            "Market Score: ${a.marketScore}/100\n" +
            "Risk Score: ${a.riskScore}/100\n" +
            "Liquidity: ${money(a.liquidity)}\n" +
            "Volume 1h: ${money(a.volume1h)}\n" +
            "Buy/Sell: ${a.buys}/${a.sells}",
            15f, Color.LTGRAY
        ))

        val s = a.security
        card.addView(tv(
            if (s == null) "Security: tidak tersedia"
            else "Top 5 holder: ${String.format(Locale.US, "%.1f%%", s.top5Pct)}\n" +
                 "Mint authority: ${if (s.mintAuthority == null) "OFF/None" else "AKTIF"}\n" +
                 "Freeze authority: ${if (s.freezeAuthority == null) "OFF/None" else "AKTIF"}",
            14f, Color.LTGRAY
        ))

        val warnText = if (a.warnings.isEmpty()) "🟢 Tidak ada warning heuristik."
        else a.warnings.joinToString("\n") { "⚠️ $it" }

        card.addView(tv(warnText, 14f,
            if (a.riskScore >= 50) Color.rgb(255, 150, 150) else Color.LTGRAY))

        card.addView(tv("\nMint:\n${a.address}", 11f, Color.GRAY))
        resultBox.addView(card)
    }

    private fun setBusy(message: String) {
        scanButton.isEnabled = false
        status.text = message
        resultBox.removeAllViews()
    }

    private fun showError(e: Exception) {
        runOnUiThread {
            status.text = "Error: ${e.message ?: "network/API error"}"
            scanButton.isEnabled = true
        }
    }

    private fun tv(text: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(0, 6, 0, 6)
        }

    private fun money(v: Double): String =
        if (v >= 1_000_000) String.format(Locale.US, "$%.2fM", v/1_000_000)
        else if (v >= 1_000) String.format(Locale.US, "$%.1fK", v/1_000)
        else String.format(Locale.US, "$%.0f", v)

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 15000
        c.readTimeout = 15000
        return try {
            if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        return try {
            if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

/* Small helper only to keep JSON parsing dependencies inside Android's standard JSON APIs. */
object JSONArrayHelper {
    fun parse(s: String): org.json.JSONArray = org.json.JSONArray(s)
}
